package Faculty;

import Admin.AdminMain;
import Student.StudentMain;
import net.proteanit.sql.DbUtils;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.text.DefaultFormatter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.ResultSet;

public class FacultyPanel extends JPanel implements ActionListener {
    private JButton addnewfaculity;

    public JTable table;

    public AdminMain am;
    public JPanel tableviewpanel;

    public StudentMain sm;
    public FacultyMain fm;
    private String condition="";
    private JLabel headinglabel;

    public FacultyPanel(AdminMain am)
    {
        this();
        this.am=am;
        table.addMouseListener(new MouseAdapter()
        {
            public void mousePressed(MouseEvent e)
            {
                if(e.getClickCount()>1  && e.getButton()==MouseEvent.BUTTON1)
                {
                    JTable t=(JTable) e.getSource();
                    int fid=Integer.parseInt(t.getValueAt(t.getSelectedRow(), 0)+"");
                    Faculty f=new FacultyData().getFacultyInfobyId(fid);

                    am.viewfacultypanel=new ViewFacultyPanel(f,am,am.facultypanel);
                    am.viewfacultypanel.setVisible(true);
                    am.facultypanel.setVisible(false);
                    am.viewfacultypanel.setLocation(am.panelx,am.panely);
                    am.viewfacultypanel.setVisible(true);
                    am.viewfacultypanel.setFocusable(true);
                    am.contentPane.add(am.viewfacultypanel);

                }

            }
        });
    }
    public FacultyPanel(FacultyMain fm)
    {
        this();
        this.fm=fm;
        headinglabel.setText("Co-Faculties");
        this.addnewfaculity.setVisible(false);
        //this.viewbutton.setLocation(addnewfaculity.getX(), addnewfaculity.getY());
        condition=" where courcecode='"+fm.f.getCourceCode()+"' and semoryear="+fm.f.getSemorYear()+" and facultyid!="+fm.f.getFacultyId();
        this.createtablemodel();
        table.addMouseListener(new MouseAdapter()
        {
            public void mousePressed(MouseEvent e)
            {
                if(e.getClickCount()>1  && e.getButton()==MouseEvent.BUTTON1)
                {
                    JTable t=(JTable) e.getSource();
                    int fid=Integer.parseInt(t.getValueAt(t.getSelectedRow(), 0)+"");
                    Faculty f=new FacultyData().getFacultyInfobyId(fid);

                    fm.viewfacultypanel=new ViewFacultyPanel(f,fm,fm.facultypanel);
                    fm.viewfacultypanel.setVisible(true);
                    fm.facultypanel.setVisible(false);
                    fm.viewfacultypanel.setLocation(fm.panelx,fm.panely);
                    fm.viewfacultypanel.setVisible(true);
                    fm.viewfacultypanel.setFocusable(true);
                    fm.contentPane.add(fm.viewfacultypanel);

                }

            }
        });
    }

    public FacultyPanel(StudentMain sm)
    {
        this();
        this.sm=sm;
        headinglabel.setText("Faculties");
        this.addnewfaculity.setVisible(false);
        //this.viewbutton.setLocation(addnewfaculity.getX(), addnewfaculity.getY());
        condition=" where courcecode='"+sm.s.getCourceCode()+"' and semoryear="+sm.s.getSemorYear()+" ";
        this.createtablemodel();
        table.addMouseListener(new MouseAdapter()
        {
            public void mousePressed(MouseEvent e)
            {
                if(e.getClickCount()>1  && e.getButton()==MouseEvent.BUTTON1)
                {
                    JTable t=(JTable) e.getSource();
                    int fid=Integer.parseInt(t.getValueAt(t.getSelectedRow(), 0)+"");
                    Faculty f=new FacultyData().getFacultyInfobyId(fid);

                    sm.viewfacultypanel=new ViewFacultyPanel(f,sm,sm.facultypanel);
                    sm.viewfacultypanel.setVisible(true);
                    sm.facultypanel.setVisible(false);
                    sm.viewfacultypanel.setLocation(sm.panelx,sm.panely);
                    sm.viewfacultypanel.setVisible(true);
                    sm.viewfacultypanel.setFocusable(true);
                    sm.contentPane.add(sm.viewfacultypanel);

                }

            }
        });
    }

    private FacultyPanel() {
        this.setName("Faculty Panel");
        setBackground(Color.WHITE);
        this.setSize(1116, 705);
        setLayout(null);
        JPanel panel = new JPanel();
        panel.setBackground(new Color(32, 178, 170));
        panel.setBounds(10, 0, 1096, 183);
        add(panel);
        panel.setLayout(null);
        headinglabel = new JLabel("All Faculties");
        headinglabel.setIcon(null);
        headinglabel.setBounds(10, 65, 272, 44);
        panel.add(headinglabel);
        headinglabel.setBackground(new Color(32, 178, 170));
        headinglabel.setHorizontalAlignment(SwingConstants.LEFT);
        headinglabel.setForeground(Color.WHITE);
        headinglabel.setFont(new Font("Segoe UI", Font.BOLD, 30));
        headinglabel.setOpaque(true);

        addnewfaculity = new JButton("Add Faculty");
        addnewfaculity.setBorder(new EmptyBorder(0, 0, 0, 0));
        addnewfaculity.setBounds(932, 139, 153, 33);
        panel.add(addnewfaculity);
        addnewfaculity.setFocusable(false);
        addnewfaculity.setForeground(new Color(0, 128, 128));
        addnewfaculity.setFont(new Font("Segoe UI", Font.BOLD, 15));
        addnewfaculity.setCursor(new Cursor(Cursor.HAND_CURSOR));

        addnewfaculity.setBackground(new Color(255, 255, 255));
        
        addnewfaculity.addActionListener(this);

        tableviewpanel = new JPanel();
        tableviewpanel.setBackground(Color.WHITE);
        tableviewpanel.setBounds(0, 189, 1116, 528);
        add(tableviewpanel);
        tableviewpanel.setLayout(null);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(10, 11, 1095, 483);
        scrollPane.setBorder(new EmptyBorder(0, 0, 0, 0));
        for(Component c : scrollPane.getComponents())
        {
            c.setBackground(Color.white);
        }
        tableviewpanel.add(scrollPane);

        table = new JTable();

        table = new JTable();
        table.setCursor(new Cursor(Cursor.HAND_CURSOR));
        table.setBorder(new LineBorder(Color.LIGHT_GRAY));
        table.getTableHeader().setBackground(new Color(32,178,170));
        table.getTableHeader().setForeground(Color.white);
        table.getTableHeader().setFont(new Font("Arial",Font.BOLD,20));
        table.setFont(new Font("Segoe UI",Font.PLAIN,20));
        table.getTableHeader().setPreferredSize(new Dimension(50,40));
        table.setDragEnabled(false);
        table.setRowHeight(40);
        createtablemodel();
        table.setSelectionBackground(new Color(240, 255, 255));
        table.setFocusable(false);
        table.setDefaultEditor(Object.class,null);
        table.setGridColor(Color.LIGHT_GRAY);
        table.getTableHeader().setReorderingAllowed(false);
        scrollPane.setViewportView(table);



    }


    @Override
    public void actionPerformed(ActionEvent e) {

        // TODO Auto-generated method stub
        if(e.getSource()==addnewfaculity)
        {
            AddFacultyDialog afd=new AddFacultyDialog(this);
            afd.setLocationRelativeTo(null);
            afd.setVisible(true);
        }

    }

    public void createtablemodel()
    {
        ResultSet rs=new FacultyData().getFacultyInfo(condition);
        if(rs!=null)
        {
            table.setModel(DbUtils.resultSetToTableModel(rs));
        }
        table.getColumnModel().getColumn(0).setMaxWidth(200);
        table.getColumnModel().getColumn(1).setMaxWidth(300);
        table.getColumnModel().getColumn(2).setMaxWidth(500);
        table.getColumnModel().getColumn(3).setMaxWidth(250);
        table.getColumnModel().getColumn(4).setMaxWidth(250);
        table.setAutoResizeMode(JTable.AUTO_RESIZE_LAST_COLUMN);
        DefaultTableCellRenderer cellrenderer=new DefaultTableCellRenderer();
        cellrenderer.setHorizontalAlignment(JLabel.CENTER);
        table.getColumnModel().getColumn(0).setCellRenderer(cellrenderer);
    }

}

