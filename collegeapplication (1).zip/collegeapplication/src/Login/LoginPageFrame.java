package Login;

import Admin.AdminData;
import Admin.Admin;
import Common.DataBaseConnection;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.MatteBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

@SuppressWarnings("serial")
public class LoginPageFrame extends JFrame implements ActionListener
{

    private JPanel contentPane;
    private JButton facultybutton;
    private JButton studentbutton;
    private JButton adminbutton;
    private LoginPanel studentloginpanel,facultyloginpanel,adminloginpanel;
    private boolean adminchanging=false,studentchanging=false,facultychanging=false;
    private int adminpanelx=-2300,adminpanely=240;
    private int facultypanelx=-900,facultypanely=240;
    private int studentpanelx=500,studentpanely=240;
    private int underlinelabelx=280,underlinelabelwidth=140;
    public Timer timer;
    private JLabel bgimagelabel;
    private JLabel underlinelabel;
    private JPanel loginbuttonpanel;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    if(DataBaseConnection.checkconnection())
                    {
                        LoginPageFrame frame = new LoginPageFrame();
                        frame.setVisible(true);
                        frame.setLocation(-7, 0);
                    }
                    else
                    {
                        JOptionPane.showMessageDialog(null, "Start the Database Server first","Error",JOptionPane.ERROR_MESSAGE);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }


    public LoginPageFrame() {
        timer=new Timer(5,this);
        setTitle("Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1380,733);
        setLocationRelativeTo(null);
        contentPane = new JPanel();
        contentPane.setBorder(new LineBorder(Color.LIGHT_GRAY, 2));
        contentPane.setBackground(new Color(255, 255, 255));
        setContentPane(contentPane);
        contentPane.setLayout(null);



        Admin ad=new AdminData().getAdminData();

        JPanel panel = new JPanel();
        panel.setBackground(new Color(0, 139, 139,220));
        panel.setBounds(0, 26, 1364, 159);
        contentPane.add(panel);
        panel.setLayout(null);

        JLabel lblCollage = new JLabel(ad.getCollageName());
        lblCollage.setForeground(Color.WHITE);
        lblCollage.setFont(new Font("Segoe UI", Font.BOLD, 30));
        lblCollage.setHorizontalAlignment(SwingConstants.LEFT);
        lblCollage.setBounds(160, 43, 800, 57);
        panel.add(lblCollage);

        JLabel lblLogo = new JLabel("logo");
        lblLogo.setBounds(10, 10, 140, 140);
        lblLogo.setIcon(new ImageIcon(ad.getRoundedProfilePic(lblLogo.getWidth(), lblLogo.getHeight(), lblLogo.getWidth())));
        //lblLogo.setIcon(new ImageIcon(ad.getRoundedProfilePic(lblLogo.getWidth(), lblLogo.getHeight(), lblLogo.getWidth())));


        panel.add(lblLogo);

        studentloginpanel=new LoginPanel("Student",new ImageIcon("./assets/studentlogin.png"),this);
        studentloginpanel.setVisible(true);
        studentloginpanel.setLocation(studentpanelx,studentpanely);

        facultyloginpanel=new LoginPanel("Faculty",new ImageIcon("./assets/facultylogin.png"),this);
        facultyloginpanel.setVisible(true);
        facultyloginpanel.setLocation(facultypanelx, facultypanely);

        adminloginpanel=new LoginPanel("Admin",new ImageIcon("./assets/adminlogin.png"),this);
        adminloginpanel.setVisible(true);
        adminloginpanel.setLocation(adminpanelx, adminpanely);


        contentPane.add(studentloginpanel);
        contentPane.add(facultyloginpanel);
        contentPane.add(adminloginpanel);


        loginbuttonpanel = new JPanel()
        {
            protected void paintComponent(Graphics g)
            {
                g.setColor( getBackground() );
                g.fillRect(0, 0, getWidth(), getHeight());
                super.paintComponent(g);
            }
        };
        loginbuttonpanel.setOpaque(false);
        loginbuttonpanel.setBackground(new Color(0,0,0,120));
        loginbuttonpanel.setBounds(500, 189, 420, 40);
        loginbuttonpanel.setLayout(null);
        contentPane.add(loginbuttonpanel);



        adminbutton = new JButton("Admin");
        adminbutton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                activeButton(adminbutton);
                disableButton(facultybutton);
                disableButton(studentbutton);
                adminchanging=true;
                studentchanging=false;
                facultychanging=false;
                timer.start();
            }
        });
        this.buttonStyle(adminbutton);
        adminbutton.setBounds(0, 0, 140, 35);
        loginbuttonpanel.add(adminbutton);


        facultybutton = new JButton("Faculty");
        facultybutton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                activeButton(facultybutton);
                disableButton(studentbutton);
                disableButton(adminbutton);
                facultychanging=true;
                adminchanging=false;
                studentchanging=false;
                timer.start();
            }
        });
        this.buttonStyle(facultybutton);
        facultybutton.setBounds(140, 0, 140, 35);
        loginbuttonpanel.add(facultybutton);

        studentbutton = new JButton("Student");
        studentbutton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                activeButton(studentbutton);
                disableButton(facultybutton);
                disableButton(adminbutton);
                studentchanging=true;
                adminchanging=false;
                facultychanging=false;
                timer.start();
            }

        });
        studentbutton.setBounds(280, 0, 140, 35);
        this.buttonStyle(studentbutton);
        loginbuttonpanel.add(studentbutton);
        activeButton(studentbutton);

        underlinelabel = new JLabel("");
        underlinelabel.setBorder(new MatteBorder(3, 0, 0, 0, (Color)Color.CYAN));
        underlinelabel.setBounds(underlinelabelx, 37, underlinelabelwidth, 4);
        loginbuttonpanel.add(underlinelabel);



        bgimagelabel = new JLabel("image");
        bgimagelabel.setBounds(0, 11, 1380, 683);
        contentPane.add(bgimagelabel);
        this.setBackgroundImage();



    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (adminchanging) {
            adminpanelx = 500;
            studentpanelx = -2300;
            facultypanelx = -900;
            underlinelabelx = 0;
            adminchanging = false;
        } else if (facultychanging) {
            adminpanelx = -2300;
            studentpanelx = -900;
            facultypanelx = 500;
            underlinelabelx = 140;
            facultychanging = false;
        } else if (studentchanging) {
            adminpanelx = -2300;
            studentpanelx = 500;
            facultypanelx = -900;
            underlinelabelx = 280; 
            studentchanging = false;
        }

        studentloginpanel.setLocation(studentpanelx, studentpanely);
        facultyloginpanel.setLocation(facultypanelx, facultypanely);
        adminloginpanel.setLocation(adminpanelx, adminpanely);
        underlinelabel.setLocation(underlinelabelx, underlinelabel.getY());

        this.repaint();
    }
    public void buttonStyle(JButton button)
    {
        button.setFocusable(true);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Segoe UI", Font.BOLD, 15));
        button.setBorder(new EmptyBorder(0,0,0,0));
        button.setBackground(Color.black);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setOpaque(false);

    }
    public void activeButton(JButton button)
    {
        button.setForeground(Color.cyan);

    }
    public void disableButton(JButton button)
    {
        button.setForeground(Color.white);
    }
    public void setBackgroundImage()
    {
        try {
            Image image=ImageIO.read(new File(".//assets//bgimage.jpg"));
            bgimagelabel.setIcon(new ImageIcon(image.getScaledInstance(bgimagelabel.getWidth(), bgimagelabel.getHeight(), Image.SCALE_SMOOTH)));

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
